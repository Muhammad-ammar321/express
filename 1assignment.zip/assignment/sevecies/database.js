
const { MongoClient } = require('mongodb');

async function inatializeDataBase() {
    const url = 'mongodb://localhost:27017';
    const client = new MongoClient(url);
    const dbName = 'Techpark';
    try {
        
        // Use connect method to connect to the server
        await client.connect();
        console.log('Connected successfully to server');
        return client.db(dbName);
        const collection = db.collection('user');
          console.log(collection)
        // the following code examples can be pasted here...
      
        return 'done.';
        
    } catch (error) {
        console.log("Data base not find",error);
        client.close()
    }
}
const databse = inatializeDataBase()
    const db= inatializeDataBase()
    console.log(db)
    async function getAllData() {
        const user = db.collection('user')
        
    }

module.exports={
    databse
}