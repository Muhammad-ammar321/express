const express = require("express");
const cookieParser = require("cookie-parser");
const jwt = require("jsonwebtoken");
const path = require("path");

const resetSecret = "resetSecret"
// const { readData, writeData } = require("./db"); // your file DB functions
const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Fake pages controller
const showPage = require('./controller/showPageController')

// Middleware to verify token
async function reset_password(req, res, next) {
    const token = req.cookies.reset;
    if (!token) {
        return res.redirect("/verifyemail");
    }
    try {
        const verified = jwt.verify(token, resetSecret);
        console.log("Verified payload:", verified);
        req.user = verified;
        next();
    } catch (err) {
        console.error("Token verify error:", err.message);
        return res.status(403).render("verify-email", { err: "Invalid or expired reset link" });
    }
}

// Controller

    async function  emailForReset(req, res) {
        const { email } = req.body;
        if (!email) {
            return res.status(401).render("verify-email", { err: "Please enter your email" });
        }
        try {
            const data = await readData();
            const student = data.students.find(s => !s.deleted_at && s.email === email.trim());
            if (!student) {
                return res.status(200).render("verify-email", { err: "Not found or maybe banned" });
            }

            const token = jwt.sign({ email: student.email }, resetSecret, { expiresIn: "5m" });
            res.cookie("reset", token, { httpOnly: true });
            console.log("Token issued for:", student.email);
            return res.redirect("/reset");
        } catch (err) {
            console.error(err);
            res.status(500).render("login", { err: "Server Error: Cannot send reset link", mess: null });
        }
    }

    async function reset(req, res) {
        try {
            const { password, conformPass } = req.body;
            if (conformPass !== password) {
                return res.status(400).render("reset-password", { err: "Password not match", mess: null });
            }

            const data = await readData();
            const idx = data.students.findIndex(s => s.email === req.user.email);
            if (idx === -1) {
                return res.status(404).render("verify-email", { err: "User not found" });
            }
            console.log(idx)
            data.students[idx].password = password;
            await writeData(data);

            res.clearCookie("reset");
            return res.render("login", { err: null, mess: "Password reset successfully" });
        } catch (err) {
            console.error(err);
            res.status(500).render("login", { err: "Server Error: Cannot reset password", mess: null });
        }
    }


// Routes
app.get('/login',showPage.login)
app.get("/verifyemail", showPage.forget);
app.post("/reset", emailForReset());
app.get("/reset", reset_password(), showPage.reset);
app.post("/login", reset());

// Server
app.listen(3010, () => console.log("Server running on http://localhost:3000"));
