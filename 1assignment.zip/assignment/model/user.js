const express = require("express");
const fs = require("fs/promises");
const path = require("path");

const app = express();
const dataPath = path.join(__dirname, "../data.json");


app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "../views"));
app.use(express.static(path.join(__dirname, "../public")));


const readData = async () => {
    const contents = await fs.readFile(dataPath, "utf8");
    return JSON.parse(contents);
};

const writeData = async (data) => {
    await fs.writeFile(dataPath, JSON.stringify(data, null, 2));
};


module.exports = {
    async create(req, res) {
        try {
            const data = await readData();  
               let newId = 1;
        if (data.students.length > 0) {
            const lastStudent = data.students[data.students.length - 1];
            newId = lastStudent.id + 1;
        }
        if(req.body.email === data.students.find(s=> s.email === req.body.email)) return res.render("register",{err:"Email already use"});
        
            const newStudent = { id : newId, ...req.body, deleted_at: null };  
            data.students.push(newStudent);  

            await writeData(data);  

            res.redirect("/login");  
        } catch (err) {
            console.error("Error in registration:", err);
            res.status(500).send("Server Error");
        }
    },

    async update(req, res) {
        try {
            
            const data = await readData();
            // console.log("data>>>>>>>>",data)
            const index = data.students.findIndex(s => s.id === req.user.id);
            // console.log(">>>>>>>>>>>>>>>>>  ",index)
            if (index === -1) return res.status(404).send("Student not found");
            
            const created_at = new Date()
            data.students[index] = { ...data.students[index], ...req.body,created_at };
            await writeData(data);
            return res.redirect("/student/profile")
        } catch (error) {
            console.error("Error updating student:", error);
            return res.status(500).send("Server error while updating student.");
        }
    },
async destroy(req, res) {
    const id = Number(req.params.id);
    try {
        const data = await readData();
        const student = data.students.find(s => s.id === id);
        if (!student) {
            return res.status(404).send("Student not found");
        }

        student.deleted_at = new Date();
        await writeData(data);

        res.send("Student deleted successfully");
    } catch (err) {
        console.error(err);
        res.status(500).send("Server Error: Cannot delete user");
    }
}

    // async destroy(req, res) {
    //     const id = req.params.id;
    //     try {
    //         const data = readData()
    //         const student = data.students.find(s => s.id === id);
    //         if (!student) return res.render('student_list',{err:"Can't find student"});

    //         student.deleted_at = new Date()
    //         await writeData(data)
    //         res.status(203).send('user deleted')
    //     } catch (err) {
    //         return err.message
    //     }
    // }
}