const data = "MVWLS-TZ3WR-RYJUC"
let a= ""
for(i=data.length-1;i>=0;i--){
    a += data[i]
    return a   
}
console.log(a)
function reverseString(str) {
    let reversedStr = '';  // Initialize an empty string to store the reversed result
    
    // Loop through the string from the last character to the first
    for (let i = str.length - 1; i >= 0; i--) {
      reversedStr += str[i];  // Append each character to the result string
    }
    
    return reversedStr;  // Return the reversed string
  }

  console.log(reverseString("MVWLS-TZ3WR-RYJUC"))